
const logout = ()=>{
    localStorage.clear()
    location.href = "/login"
}